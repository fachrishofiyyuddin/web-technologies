<!DOCTYPE html>
<html>
    <head>
        <title>profil</title>
        <h3>informasi pribadi</h3>
        <p>nama: fardiyan murtadlo</p>
        <p>usia:14 tahun</p>
        <p>pekerjaan: pelajar</p>
        <p>foto profil</p>
        <img src="image/htmllogo.png" width="100" alt="foto profil"><br>
        <a href="index.php">halaman utama</a>
        
    </head>
</html>