<!DOCTYPE html>
<html>
    <head>
        <title>form</title>
        <body>
            <h3>kontak saya</h3>
            <p>untuk menghubungi saya,kirim pesan melalui form di bawah</p>
            <form><br>
                <label>nama:</label>
                <input type="text"><br>
                <label>email:</label>
                <input type="email"><br>
                <label:>pesan:</label:>
                <textarea></textarea><br>
                <button>kirim pesan</button><br>
                <a href="index.php">halaman utama</a>
                <a href="https://www.facebook.com/login/?next=https%3A%2F%2Fwww.facebook.com%2F%3Flocale%3Did_ID">facebook  </a>
            </form>
        </body>
    </head>
</html>