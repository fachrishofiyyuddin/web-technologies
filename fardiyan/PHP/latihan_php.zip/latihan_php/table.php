<!DOCTYPE html>
<html>
    <head>
        <title>table</title>
        <body>   
            <table border="1">
                <thead>
                    <tr>
                        <th>nomer</th>
                        <th>nama</th>
                        <th>email</th>
                        <th>pesan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>fardiyan</td>
                        <td>fardiyan@gmail.com</td>
                        <td>test</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>surur</td>
                        <td>surur@gmail.com</td>
                        <td>test</td>
                    </tr>
                </tbody>
            </table>
            <a href="index.php">halaman utama</a>
        </body>
    </head>
</html>