<!DOCTYPE html>
<html>
    <head>
        <title>halaman utama</title>
        <body>
            <h1>selamat datang di profil saya</h1>
            <a href="profil.php">profil</a><br>
            <a href="form.php">form</a><br>
            <a href="list.php">list</a><br>
            <a href="table.php">table</a>
        </body>
    </head>
</html>