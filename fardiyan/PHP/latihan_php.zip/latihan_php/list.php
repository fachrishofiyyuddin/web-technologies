<!DOCTYPE html>
<HTTML>
    <HEAD>
        <title>list</title>
        <body>
            <p>menu makanan</p>
            <ul>
                <li>ayam geprek</li>
                <li>nasi goreng</li>
                <li>telur dadar</li>
            </ul>
            <ol>
                <li>ayam geprek</li>
                <li>nasi goreng</li>
            </ol>
            <a href="index.php">halaman utama</a>
        </body>
    </HEAD>
</HTTML>