<!DOCTYPE html>
<html>
    <head>
        <title>table</title>
    </head>
    <body>
        <table border="1">
         <thead>
                <tr>
                    <th>nomor</th>
                    <th>nama</th>
                    <th>email</th>
                    <th>pesan</th>
                </tr>
         </thead>
         <tbody>
                <tr>
                     <td>1</td>
                     <td>surur</td>
                     <td>surur@gmail.com</td>
                     <td>ini pesan saya</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>fardiyan</td>
                    <td>fardiyan@gmail.com</td>
                    <td>ini pesan saya</td>
               </tr>
         </tbody>
         </table><br>
<a href="index.php">kembali e halaman utama</a>
    </body>
</html>