<!DOCTYPE html>
<html>
    <head>
        <title>list</title>
    </head>
    <body>
        <p>menu makanan</p>
        <ul>
            <li>nasi goreng</li>
            <li>mie ayam</li>
            <li>bakso</li>
            <li>ayam geprek</li>
        </ul>
        menu minuman
        <ol>
            <li>es teh</li>
            <li>es sirup</li>
            <li>es jeruk</li>
            <li>es serut</li>
        </ol>
<a href="index.php">kembali ke halaman utama</a>

    </body>
    
</html>