<!DOCTYPE html>
<html>
    <head>
        <title>form</title>
    </head>
    <body>
        <h1>kontak saya</h1>
        <p>untuk menghubungi saya,hubungi pesan melalui form dibawah</p>
    <label>nama</label>
    <input type="teks"><br>
    <label>email</label>
    <input type="email"><br>
    <label>pesan</label>
    <textarea></textarea><br>
    <button>krim pesan</button><br><br>
    <a href="index.php">kembali ke menu utama</a><br>
    </body>
</html>