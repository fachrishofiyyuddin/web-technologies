<!DOCTYPE html>
<html>
    <head>
        <title>index</title>
    </head>
    <body>
        <h1>selamat datang diprofil saya</h1>
        <p>menu:</p>
<a href="profil.php">profil</a><br>
<a href="form.php">form</a><br>
<a href="table.php">table</a><br>
<a href="list.php">list</a>
    </body>
</html>