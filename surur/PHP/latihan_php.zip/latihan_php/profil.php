<!DOCTYPE html>
<html>
    <head>
        <title>profil</title>
    </head>
    <body>
        <p>nama:muhammad miftakhus surur</p>
        <p>usia:15 tahun</p>
        <p>pekerjaan:pelajar</p>
        <img src="image/ronaldo.jpg"><br><br>
        <a href="index.php">kembali ke halaman utama</a>
    </body>
</html>